//
//  MySampleSDK.h
//  MySampleSDK
//
//  Created by H454944 on 21/07/23.
//

#import <Foundation/Foundation.h>

//! Project version number for MySampleSDK.
FOUNDATION_EXPORT double MySampleSDKVersionNumber;

//! Project version string for MySampleSDK.
FOUNDATION_EXPORT const unsigned char MySampleSDKVersionString[];
#import <MySampleSDK/MySDK.h>
// In this header, you should import all the public headers of your framework using statements like #import <MySampleSDK/PublicHeader.h>


